import pg from 'pg';

const { Pool } = pg;

const isLocal = /localhost|127\.0\.0\.1/.test(process.env.DATABASE_URL || '');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: isLocal ? false : { rejectUnauthorized: false },
});

export async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      username TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      full_name TEXT,
      bio TEXT DEFAULT '',
      avatar_url TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );

    CREATE TABLE IF NOT EXISTS photos (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      image_url TEXT NOT NULL,
      image_key TEXT NOT NULL,
      caption TEXT DEFAULT '',
      location TEXT DEFAULT '',
      camera TEXT DEFAULT '',
      lens TEXT DEFAULT '',
      likes_count INTEGER NOT NULL DEFAULT 0,
      dislikes_count INTEGER NOT NULL DEFAULT 0,
      attested_original BOOLEAN NOT NULL DEFAULT false,
      has_camera_exif BOOLEAN NOT NULL DEFAULT false,
      exif_camera_make TEXT,
      exif_camera_model TEXT,
      exif_taken_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );

    -- Safe to re-run: adds the verification columns for databases created before this feature existed.
    ALTER TABLE photos ADD COLUMN IF NOT EXISTS attested_original BOOLEAN NOT NULL DEFAULT false;
    ALTER TABLE photos ADD COLUMN IF NOT EXISTS has_camera_exif BOOLEAN NOT NULL DEFAULT false;
    ALTER TABLE photos ADD COLUMN IF NOT EXISTS exif_camera_make TEXT;
    ALTER TABLE photos ADD COLUMN IF NOT EXISTS exif_camera_model TEXT;
    ALTER TABLE photos ADD COLUMN IF NOT EXISTS exif_taken_at TIMESTAMPTZ;

    CREATE TABLE IF NOT EXISTS reports (
      id TEXT PRIMARY KEY,
      photo_id TEXT NOT NULL REFERENCES photos(id) ON DELETE CASCADE,
      reporter_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      reason TEXT DEFAULT '',
      created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      UNIQUE(photo_id, reporter_id)
    );

    CREATE TABLE IF NOT EXISTS reactions (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      photo_id TEXT NOT NULL REFERENCES photos(id) ON DELETE CASCADE,
      type TEXT NOT NULL CHECK (type IN ('like', 'dislike')),
      created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      UNIQUE(user_id, photo_id)
    );

    CREATE INDEX IF NOT EXISTS idx_photos_user ON photos(user_id);
    CREATE INDEX IF NOT EXISTS idx_photos_created ON photos(created_at);
    CREATE INDEX IF NOT EXISTS idx_reactions_photo ON reactions(photo_id);
    CREATE INDEX IF NOT EXISTS idx_reports_photo ON reports(photo_id);
  `);
}

export default pool;
