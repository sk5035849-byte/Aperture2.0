import { Router } from 'express';
import multer from 'multer';
import { nanoid } from 'nanoid';
import pool from '../db.js';
import { uploadToR2, deleteFromR2 } from '../storage.js';
import { extractExif } from '../exif.js';
import { requireAuth, optionalAuth } from '../middleware/auth.js';

const ALLOWED_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp', 'image/gif']);

// Files land in memory, then get streamed to Cloudflare R2 (no local disk writes,
// which matters on Render's ephemeral filesystem).
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 15 * 1024 * 1024, files: 10 },
  fileFilter: (_req, file, cb) => {
    if (!ALLOWED_TYPES.has(file.mimetype)) {
      return cb(new Error('Only JPG, PNG, WEBP, or GIF images are allowed.'));
    }
    cb(null, true);
  },
});

const router = Router();

function attachViewerReaction(photo, userId, viewerReactions) {
  if (!userId) return { ...photo, viewer_reaction: null };
  return { ...photo, viewer_reaction: viewerReactions.get(photo.id) || null };
}

async function getViewerReactions(photoIds, userId) {
  const map = new Map();
  if (!userId || photoIds.length === 0) return map;
  const { rows } = await pool.query(
    'SELECT photo_id, type FROM reactions WHERE user_id = $1 AND photo_id = ANY($2)',
    [userId, photoIds]
  );
  rows.forEach((r) => map.set(r.photo_id, r.type));
  return map;
}

async function attachAuthors(photos) {
  if (photos.length === 0) return [];
  const userIds = [...new Set(photos.map((p) => p.user_id))];
  const { rows: authors } = await pool.query(
    'SELECT id, username, full_name, avatar_url FROM users WHERE id = ANY($1)',
    [userIds]
  );
  const authorMap = new Map(authors.map((a) => [a.id, a]));
  return photos.map((p) => ({ ...p, author: authorMap.get(p.user_id) }));
}

// --- Upload up to 10 photos in one post ---
router.post('/', requireAuth, upload.array('photos', 10), async (req, res, next) => {
  try {
    const files = req.files || [];
    if (files.length === 0) {
      return res.status(400).json({ error: 'Attach at least one photo.' });
    }

    // No-AI policy gate: publishing requires confirming these are the uploader's
    // own real photographs. This doesn't prove it alone — the EXIF check below adds
    // real signal — but it sets a clear, enforceable community standard up front.
    if (req.body.attested_original !== 'true') {
      return res.status(400).json({
        error: 'You must confirm these are your own original, non-AI-generated photographs before publishing.',
      });
    }

    let meta = [];
    try {
      meta = req.body.meta ? JSON.parse(req.body.meta) : [];
    } catch {
      meta = [];
    }

    const created = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const m = meta[i] || {};
      const [{ key, url }, exif] = await Promise.all([uploadToR2(file), extractExif(file.buffer)]);
      const id = nanoid();

      const { rows } = await pool.query(
        `INSERT INTO photos
           (id, user_id, image_url, image_key, caption, location, camera, lens,
            attested_original, has_camera_exif, exif_camera_make, exif_camera_model, exif_taken_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, true, $9, $10, $11, $12)
         RETURNING *`,
        [
          id, req.userId, url, key, m.caption || '', m.location || '', m.camera || '', m.lens || '',
          exif.hasCameraExif, exif.make, exif.model, exif.takenAt,
        ]
      );
      created.push(rows[0]);
    }

    const withAuthors = await attachAuthors(created);
    res.status(201).json({ photos: withAuthors.map((p) => ({ ...p, viewer_reaction: null })) });
  } catch (err) {
    next(err);
  }
});

// --- Feed: newest first ---
router.get('/feed', optionalAuth, async (req, res, next) => {
  try {
    const { rows } = await pool.query(
      'SELECT * FROM photos ORDER BY created_at DESC LIMIT 100'
    );
    const withAuthors = await attachAuthors(rows);
    const viewerReactions = await getViewerReactions(rows.map((p) => p.id), req.userId);
    res.json({ photos: withAuthors.map((p) => attachViewerReaction(p, req.userId, viewerReactions)) });
  } catch (err) {
    next(err);
  }
});

// --- Explore: most liked overall (optionally filtered to verified-original only) ---
router.get('/explore', optionalAuth, async (req, res, next) => {
  try {
    const verifiedOnly = req.query.verified === 'true';
    const { rows } = await pool.query(
      `SELECT * FROM photos
       ${verifiedOnly ? 'WHERE has_camera_exif = true AND attested_original = true' : ''}
       ORDER BY likes_count DESC, created_at DESC LIMIT 100`
    );
    const withAuthors = await attachAuthors(rows);
    const viewerReactions = await getViewerReactions(rows.map((p) => p.id), req.userId);
    res.json({ photos: withAuthors.map((p) => attachViewerReaction(p, req.userId, viewerReactions)) });
  } catch (err) {
    next(err);
  }
});

// --- Trending: most liked photo(s) posted today ---
router.get('/trending', optionalAuth, async (req, res, next) => {
  try {
    const { rows } = await pool.query(
      `SELECT * FROM photos
       WHERE created_at::date = now()::date
       ORDER BY likes_count DESC, created_at ASC
       LIMIT 20`
    );
    const withAuthors = await attachAuthors(rows);
    const viewerReactions = await getViewerReactions(rows.map((p) => p.id), req.userId);
    res.json({ photos: withAuthors.map((p) => attachViewerReaction(p, req.userId, viewerReactions)) });
  } catch (err) {
    next(err);
  }
});

// --- Single photo detail ---
router.get('/:id', optionalAuth, async (req, res, next) => {
  try {
    const { rows } = await pool.query('SELECT * FROM photos WHERE id = $1', [req.params.id]);
    if (!rows[0]) return res.status(404).json({ error: 'Photo not found.' });
    const [withAuthor] = await attachAuthors(rows);
    const viewerReactions = await getViewerReactions([rows[0].id], req.userId);
    res.json({ photo: attachViewerReaction(withAuthor, req.userId, viewerReactions) });
  } catch (err) {
    next(err);
  }
});

// --- Delete own photo ---
router.delete('/:id', requireAuth, async (req, res, next) => {
  try {
    const { rows } = await pool.query('SELECT * FROM photos WHERE id = $1', [req.params.id]);
    const photo = rows[0];
    if (!photo) return res.status(404).json({ error: 'Photo not found.' });
    if (photo.user_id !== req.userId) {
      return res.status(403).json({ error: 'You can only delete your own photos.' });
    }

    await pool.query('DELETE FROM photos WHERE id = $1', [req.params.id]);
    await deleteFromR2(photo.image_key);

    res.json({ success: true });
  } catch (err) {
    next(err);
  }
});

// --- Like / dislike (mutually exclusive, toggleable) ---
function react(type) {
  const other = type === 'like' ? 'dislike' : 'like';
  return async (req, res, next) => {
    try {
      const { rows: photoRows } = await pool.query('SELECT * FROM photos WHERE id = $1', [req.params.id]);
      if (!photoRows[0]) return res.status(404).json({ error: 'Photo not found.' });

      const { rows: existingRows } = await pool.query(
        'SELECT * FROM reactions WHERE user_id = $1 AND photo_id = $2',
        [req.userId, req.params.id]
      );
      const existing = existingRows[0];

      const client = await pool.connect();
      try {
        await client.query('BEGIN');

        if (existing && existing.type === type) {
          await client.query('DELETE FROM reactions WHERE id = $1', [existing.id]);
          await client.query(
            `UPDATE photos SET ${type}s_count = ${type}s_count - 1 WHERE id = $1`,
            [req.params.id]
          );
        } else if (existing) {
          await client.query('UPDATE reactions SET type = $1 WHERE id = $2', [type, existing.id]);
          await client.query(
            `UPDATE photos SET ${other}s_count = ${other}s_count - 1, ${type}s_count = ${type}s_count + 1 WHERE id = $1`,
            [req.params.id]
          );
        } else {
          await client.query(
            'INSERT INTO reactions (id, user_id, photo_id, type) VALUES ($1, $2, $3, $4)',
            [nanoid(), req.userId, req.params.id, type]
          );
          await client.query(
            `UPDATE photos SET ${type}s_count = ${type}s_count + 1 WHERE id = $1`,
            [req.params.id]
          );
        }

        await client.query('COMMIT');
      } catch (err) {
        await client.query('ROLLBACK');
        throw err;
      } finally {
        client.release();
      }

      const { rows: updatedRows } = await pool.query('SELECT * FROM photos WHERE id = $1', [req.params.id]);
      const [withAuthor] = await attachAuthors(updatedRows);
      const viewerReactions = await getViewerReactions([req.params.id], req.userId);
      res.json({ photo: attachViewerReaction(withAuthor, req.userId, viewerReactions) });
    } catch (err) {
      next(err);
    }
  };
}

router.post('/:id/like', requireAuth, react('like'));
router.post('/:id/dislike', requireAuth, react('dislike'));

// --- Report a photo (e.g. suspected AI-generated or stolen work) ---
router.post('/:id/report', requireAuth, async (req, res, next) => {
  try {
    const { rows: photoRows } = await pool.query('SELECT id FROM photos WHERE id = $1', [req.params.id]);
    if (!photoRows[0]) return res.status(404).json({ error: 'Photo not found.' });

    const reason = (req.body?.reason || '').slice(0, 500);

    await pool.query(
      `INSERT INTO reports (id, photo_id, reporter_id, reason)
       VALUES ($1, $2, $3, $4)
       ON CONFLICT (photo_id, reporter_id) DO NOTHING`,
      [nanoid(), req.params.id, req.userId, reason]
    );

    res.json({ success: true });
  } catch (err) {
    next(err);
  }
});

export default router;
