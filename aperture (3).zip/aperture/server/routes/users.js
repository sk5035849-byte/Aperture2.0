import { Router } from 'express';
import pool from '../db.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();

function publicUser(u) {
  if (!u) return null;
  const { password_hash, ...rest } = u;
  return rest;
}

router.get('/:username', async (req, res, next) => {
  try {
    const { rows: userRows } = await pool.query('SELECT * FROM users WHERE username = $1', [req.params.username]);
    const user = userRows[0];
    if (!user) return res.status(404).json({ error: 'Photographer not found.' });

    const { rows: photos } = await pool.query(
      'SELECT * FROM photos WHERE user_id = $1 ORDER BY created_at DESC',
      [user.id]
    );

    const { rows: statsRows } = await pool.query(
      'SELECT COUNT(*)::int as photo_count, COALESCE(SUM(likes_count), 0)::int as total_likes FROM photos WHERE user_id = $1',
      [user.id]
    );

    res.json({ user: publicUser(user), photos, stats: statsRows[0] });
  } catch (err) {
    next(err);
  }
});

router.patch('/me', requireAuth, async (req, res, next) => {
  try {
    const { full_name, bio, username } = req.body || {};

    if (username) {
      if (!/^[a-zA-Z0-9_.]{3,20}$/.test(username)) {
        return res.status(400).json({ error: 'Username must be 3-20 characters: letters, numbers, underscore, or dot.' });
      }
      const { rows: clashRows } = await pool.query(
        'SELECT id FROM users WHERE username = $1 AND id != $2',
        [username, req.userId]
      );
      if (clashRows[0]) return res.status(409).json({ error: 'That username is already taken.' });
    }

    const { rows: currentRows } = await pool.query('SELECT * FROM users WHERE id = $1', [req.userId]);
    const current = currentRows[0];

    const { rows: updatedRows } = await pool.query(
      'UPDATE users SET full_name = $1, bio = $2, username = $3 WHERE id = $4 RETURNING *',
      [full_name ?? current.full_name, bio ?? current.bio, username || current.username, req.userId]
    );

    res.json({ user: publicUser(updatedRows[0]) });
  } catch (err) {
    next(err);
  }
});

export default router;
