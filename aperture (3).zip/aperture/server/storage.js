import { S3Client, PutObjectCommand, DeleteObjectCommand } from '@aws-sdk/client-s3';
import { nanoid } from 'nanoid';
import path from 'path';

const r2 = new S3Client({
  region: 'auto',
  endpoint: `https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
  credentials: {
    accessKeyId: process.env.R2_ACCESS_KEY_ID,
    secretAccessKey: process.env.R2_SECRET_ACCESS_KEY,
  },
});

const BUCKET = process.env.R2_BUCKET_NAME;
// e.g. https://pub-xxxxxxxx.r2.dev  or  https://cdn.yourdomain.com  (no trailing slash)
const PUBLIC_URL = (process.env.R2_PUBLIC_URL || '').replace(/\/$/, '');

export async function uploadToR2(file) {
  const ext = path.extname(file.originalname).toLowerCase();
  const key = `${nanoid()}${ext}`;

  await r2.send(
    new PutObjectCommand({
      Bucket: BUCKET,
      Key: key,
      Body: file.buffer,
      ContentType: file.mimetype,
    })
  );

  return { key, url: `${PUBLIC_URL}/${key}` };
}

export async function deleteFromR2(key) {
  if (!key) return;
  try {
    await r2.send(new DeleteObjectCommand({ Bucket: BUCKET, Key: key }));
  } catch (err) {
    console.error('R2 delete failed (ignored):', err.message);
  }
}
