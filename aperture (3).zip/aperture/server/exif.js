import * as exifr from 'exifr';

// Reads camera metadata straight from the image bytes. A photo carrying intact
// Make/Model/DateTimeOriginal tags is strong evidence it came out of a real camera —
// AI generators and most screenshot/re-save pipelines don't produce these fields,
// and they're easy to check but inconvenient to fake convincingly.
export async function extractExif(buffer) {
  try {
    const data = await exifr.parse(buffer, {
      pick: ['Make', 'Model', 'DateTimeOriginal', 'LensModel'],
    });

    if (!data || (!data.Make && !data.Model)) {
      return { hasCameraExif: false, make: null, model: null, takenAt: null };
    }

    return {
      hasCameraExif: true,
      make: data.Make || null,
      model: data.Model || null,
      takenAt: data.DateTimeOriginal instanceof Date ? data.DateTimeOriginal.toISOString() : null,
    };
  } catch {
    // Not every valid image has parseable EXIF (e.g. PNGs, stripped metadata) —
    // that's not an error, it just doesn't qualify for the verified badge.
    return { hasCameraExif: false, make: null, model: null, takenAt: null };
  }
}
