# Aperture 📷

A social app built for photographers — upload up to 10 photos at a time, get liked (or disliked), and compete for **Trending Photo of the Day**.

## Features

- Email/password auth (JWT-based)
- Upload up to 10 photos per post, each with caption, location, camera, and lens metadata
- Like / Dislike (mutually exclusive, live counts)
- **Trust & verification**: publishing requires confirming the work is original and not AI-generated; photos with intact camera EXIF metadata get an automatic **Verified Original** badge, and anyone can report suspected fakes
- **Feed** — newest photos from everyone
- **Explore** — most-liked photos, masonry grid, with a "Verified only" filter
- **Trending** — the most-liked photo posted *today* gets the crown, resets at midnight
- **Profile** — your grid, bio, stats, edit, delete your own photos

## Stack

- **Frontend:** React + Vite + Tailwind CSS + React Router
- **Backend:** Node.js + Express + **PostgreSQL** (via `pg`) + JWT auth + Multer (in-memory) + **Cloudflare R2** for photo storage
- No local files to lose: the database and uploaded photos both live in managed, persistent services, so they survive restarts and redeploys (including on Render's free tier).

## Project structure

```
aperture/
├── server/          # Express API + Postgres + R2 storage
│   ├── index.js
│   ├── db.js        # Postgres connection + schema setup
│   ├── storage.js   # Cloudflare R2 upload/delete helpers
│   ├── middleware/auth.js
│   ├── routes/auth.js
│   ├── routes/photos.js
│   └── routes/users.js
└── client/          # React frontend (Vite)
    └── src/
```

## Getting started

Because photos live in Cloudflare R2 and data lives in Postgres, you need both set up before running locally — even for local development. Both have free tiers, and it only takes a few minutes.

### 1. Create a free Postgres database

Easiest path: use Render's free Postgres (it accepts external connections, so it works for local dev too).

1. Go to [render.com](https://render.com) → **New → PostgreSQL** → pick the free plan → create.
2. Once it's ready, copy the **External Database URL** shown on its page.

(Any Postgres works — [Neon](https://neon.tech) and [Supabase](https://supabase.com) also have generous free tiers if you'd rather use one of those.)

### 2. Create a free Cloudflare R2 bucket

1. Sign up at [dash.cloudflare.com](https://dash.cloudflare.com) (free tier: 10GB storage, no egress fees).
2. Go to **R2 Object Storage** → **Create bucket** → name it e.g. `aperture-photos`.
3. Open the bucket → **Settings** → under **Public access**, enable the **R2.dev subdomain**. Copy the resulting URL (looks like `https://pub-xxxxxxxx.r2.dev`) — this is your `R2_PUBLIC_URL`.
4. Go to **R2 → Manage API Tokens** → **Create API Token** → give it **Object Read & Write** permission, scoped to your bucket. Copy the **Access Key ID** and **Secret Access Key**.
5. Your **Account ID** is shown in the R2 overview page sidebar.

### 3. Configure the backend

```bash
cd server
npm install
```

Edit `server/.env` (already present, gitignored) and fill in the real values:

```
DATABASE_URL=<paste your Postgres connection string>
R2_ACCOUNT_ID=<your Cloudflare account id>
R2_ACCESS_KEY_ID=<your R2 access key id>
R2_SECRET_ACCESS_KEY=<your R2 secret access key>
R2_BUCKET_NAME=aperture-photos
R2_PUBLIC_URL=<your r2.dev or custom domain URL, no trailing slash>
```

Then run:

```bash
npm run dev
```

The API runs at `http://localhost:4000` and automatically creates all tables in Postgres on first run.

### 4. Run the frontend

In a separate terminal:

```bash
cd client
npm install
npm run dev
```

The app runs at `http://localhost:5173` and talks to the API at `http://localhost:4000`.

### 5. Try it out

1. Open `http://localhost:5173`
2. Sign up with a username, email, and password
3. Click **Upload**, drop in up to 10 photos, add captions/metadata, publish — they're stored in your R2 bucket
4. Like/dislike photos, check Explore and Trending

## Pushing this to GitHub

From the `aperture/` folder (the one containing this README):

```bash
git init
git add .
git commit -m "Initial commit: Aperture photographer app"
git branch -M main
```

Then create an empty repo on GitHub (don't initialize it with a README), and:

```bash
git remote add origin https://github.com/YOUR_USERNAME/aperture.git
git push -u origin main
```

If you use SSH instead of HTTPS:

```bash
git remote add origin git@github.com:YOUR_USERNAME/aperture.git
git push -u origin main
```

> `server/.env` is gitignored, so your real Postgres and R2 credentials won't be committed.

## Deploying to Render (free, live on the internet, and actually persistent)

This repo includes a `render.yaml` Blueprint. Since you already set up R2 above, deployment reuses that same bucket, and creates a fresh free Postgres database.

### Steps

1. Push this repo to GitHub (see above).
2. Go to [render.com](https://render.com) → **New → Blueprint** → connect your GitHub repo.
3. Render reads `render.yaml` and creates:
   - `aperture-db` — a free Postgres database
   - `aperture-api` — the Express backend (automatically wired to `aperture-db` via `DATABASE_URL`)
   - `aperture-client` — the static React frontend
4. During setup, Render will prompt you for the env vars marked `sync: false` — fill in your R2 credentials (`R2_ACCOUNT_ID`, `R2_ACCESS_KEY_ID`, `R2_SECRET_ACCESS_KEY`, `R2_BUCKET_NAME`, `R2_PUBLIC_URL`) from step 2 above.
5. After the first deploy, connect the two services to each other (they can't know each other's URL until both exist):
   - Open **aperture-client** → note its URL, e.g. `https://aperture-client.onrender.com`
   - Open **aperture-api** → **Environment** → set `CLIENT_ORIGIN` to that URL → save (triggers redeploy)
   - Open **aperture-api** → note its URL, e.g. `https://aperture-api.onrender.com`
   - Open **aperture-client** → **Environment** → set `VITE_API_URL` to `https://aperture-api.onrender.com/api` → save (triggers redeploy, since Vite bakes env vars in at build time)
6. Open the client URL — the app is live, and this time your data actually sticks around: Postgres and R2 are both durable, so redeploys and idle spin-downs won't wipe anything.

### Manual setup (if you'd rather not use the Blueprint)

**Backend (Web Service):**
- Root directory: `server`
- Build command: `npm install`
- Start command: `npm start`
- Environment variables: `JWT_SECRET`, `CLIENT_ORIGIN`, `DATABASE_URL`, `R2_ACCOUNT_ID`, `R2_ACCESS_KEY_ID`, `R2_SECRET_ACCESS_KEY`, `R2_BUCKET_NAME`, `R2_PUBLIC_URL`

**Frontend (Static Site):**
- Root directory: `client`
- Build command: `npm install && npm run build`
- Publish directory: `dist`
- Environment variable: `VITE_API_URL` = `https://YOUR-BACKEND-URL.onrender.com/api`
- Add a rewrite rule: `/*` → `/index.html` (so React Router's client-side routes work on refresh)

## What to change before real deployment

- Rate limiting and stricter file-type/size validation on uploads
- Build a lightweight admin view for the `reports` table so flagged photos can actually be reviewed and removed
- Add email verification for signup
- Add a `follows` table if you want a personalized Feed instead of "everyone's photos"
- Add hashtags/categories for better browsing on Explore

## Ideas for next features

- Comments
- Follow / following + personalized feed
- Search photographers by username
- Hashtags / categories (landscape, portrait, street…)
- Avatar upload UI (field already exists in the schema)
